# VS Code + GitHub + Google Sheets API Project

This repository is set up as a starter workspace for a project that uses:

- VS Code for local development
- GitHub for source control
- Google Sheets as a lightweight early-stage database
- A middle-layer API so the frontend never talks to Google Sheets directly

Read the project brief in [agent.md](agent.md).

## AGT Skills

The full AGT Skill Pack is bundled under:

```text
.claude/skills/
```

See [AGT_SKILLS.md](AGT_SKILLS.md) for the installed skill list and setup notes.

## Use On Another Machine

Clone this repository, or download and extract:

```text
agt-skill-pack-all.zip
```

Then copy the bundled skills into another project if needed:

Windows PowerShell:

```powershell
.\install-agt-skills.ps1 -Destination "C:\path\to\other\project"
```

Bash:

```bash
bash ./install-agt-skills.sh /path/to/other/project
```

## Security Rule

Keep Google credentials and Sheet access behind the API layer. Do not expose
service account keys, API keys, Sheet IDs, or private Apps Script URLs in
frontend code.
