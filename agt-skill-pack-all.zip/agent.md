# Project Brief For Codex

## Goal

Build a project workflow using VS Code, GitHub, and Google Sheets as a lightweight database.

## Core Idea

- Use VS Code as the local development environment.
- Store and version the source code in GitHub.
- Use Google Sheets as a simple, editable database for early-stage data.
- Connect the app to Google Sheets through a middle layer API.
- Do not connect the frontend directly to Google Sheets with exposed credentials.

## Recommended Architecture

```text
Frontend / App
    -> Backend API or Google Apps Script
    -> Google Sheets
```

## Why This Is A Good Fit

- Good for MVPs, prototypes, dashboards, admin tools, catalogs, booking systems, stock lists, and simple order tracking.
- Easy for non-technical users to view and edit data directly in Google Sheets.
- Fast to start without building a full admin panel.
- GitHub keeps the code organized and ready for collaboration or deployment.

## Important Cautions

- Treat Google Sheets as a lightweight database, not a full production database.
- Avoid putting API keys, tokens, service account credentials, or private sheet access directly in frontend code.
- Use environment variables and keep secrets out of GitHub.
- Expect limits around speed, quota, concurrent writes, and complex queries.
- If the app grows, plan to migrate later to a real database such as Supabase, PostgreSQL, Firebase, or another managed database.

## Design Principle

Keep the data access layer separate from the frontend so the storage can be changed later without rebuilding the whole app.

## Future Migration Path

Start with:

```text
App -> API layer -> Google Sheets
```

Later, if needed, migrate to:

```text
App -> API layer -> PostgreSQL / Supabase / Firebase
```

The frontend should keep calling the same API routes as much as possible.

## Instructions For Codex In A New Folder

When continuing this project, assume the user wants:

- A VS Code project.
- GitHub-ready source control.
- Google Sheets used as a lightweight database.
- A backend or Google Apps Script API layer between the app and Google Sheets.
- Secure handling of secrets through environment variables.
- A structure that can migrate to a real database later.

If implementation details are missing, ask for:

1. The app stack, such as React, Next.js, Node.js, Python, or another framework.
2. The data tables needed, such as users, products, orders, bookings, or settings.
3. Whether to create a new Google Sheet or connect to an existing one.
